my list drawing
